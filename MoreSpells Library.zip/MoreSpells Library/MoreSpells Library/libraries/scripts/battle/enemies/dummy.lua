local Dummy, super = Class(EnemyBattler)

function Dummy:init()
    super.init(self)

    self.name = "Dummy"

    self:setActor("dummy")


    self.max_health = 5000
    self.health = 5000

    self.attack = 4

    self.defense = 0

    self.money = 100

    self.spare_points = 20

    self.waves = {
        "basic",
        "aiming",
        "movingarena"
    }

    self.dialogue = {
        "..."
    }

    self.check = "AT 4 DF 0\n* Cotton heart and button eye\n* Looks just like a fluffy guy."

    self.text = {
        "* The dummy gives you a soft\nsmile.",
        "* The power of fluffy boys is\nin the air.",
        "* Smells like cardboard.",
    }
 
    self.low_health_text = "* The dummy looks like it's\nabout to fall over."

    self:registerAct("SYMBIOSIS", "ATK and\nDEF up", "kris", 75)
end

function Dummy:onAct(battler, name)
        if name == "SYMBIOSIS" then
            Game.battle:powerAct("symbiosis_dw", battler, "kris", self)
    end
    return super.onAct(self, battler, name)
end

return Dummy